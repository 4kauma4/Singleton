﻿using System;
using System.Collections.Generic;
using System.Linq;

public class ServersSingl
{
    private HashSet<string> servers = new HashSet<string>();
    private static readonly ServersSingl instance = new ServersSingl();
    private static readonly object lockObject = new object();

    public static ServersSingl Instance => instance;

    private ServersSingl() { }

    public bool AddServer(string serverUrl)
    {
        //  URL с http или https
        if (string.IsNullOrWhiteSpace(serverUrl) ||
            (!serverUrl.StartsWith("http://") && !serverUrl.StartsWith("https://")))
        {
            return false;
        }

        lock (lockObject)
        {
            return servers.Add(serverUrl); // возврат bool по результату добавления
        }
    }

    public List<string> GetHttpServers() // url серверов с http
    {
        lock (lockObject)
        {
            return servers.Where(url => url.StartsWith("http://")).ToList();
        }
    }

    public List<string> GetHttpsServers() // url серверов с https
    {
        lock (lockObject)
        {
            return servers.Where(url => url.StartsWith("https://")).ToList();
        }
    }
}

