﻿using System;

class Program
{
    static void Main()
    {

        ServersSingl servers = ServersSingl.Instance;


        Console.WriteLine(servers.AddServer("http://singl.com"));//true
        Console.WriteLine(servers.AddServer("https://singl.com"));// true
        Console.WriteLine(servers.AddServer("ftp://singl.com"));// false
        Console.WriteLine(servers.AddServer("https://singl.com"));// дупликат - false


        Console.WriteLine("http: ");
        foreach (var server in servers.GetHttpServers())
        {
            Console.WriteLine(server);
        }

        Console.WriteLine("https: ");
        foreach (var server in servers.GetHttpsServers())
        {
            Console.WriteLine(server);
        }
    }
}
